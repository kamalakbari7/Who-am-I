module ModernResumeTheme
  VERSION = "2.0.2"
end
